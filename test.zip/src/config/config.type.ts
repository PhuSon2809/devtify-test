export interface IConfig {
  dummyApi: string
}
