import { cn } from '@/shared/utils'
import { memo, useEffect, useMemo, useRef, useState } from 'react'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table'
import { Loader } from 'lucide-react'

export interface Column {
  key: string
  label: React.ReactNode
  width?: number
  render?: (row: any, idx?: number) => React.ReactNode
  sortable?: boolean
  getValue?: (row: any) => unknown
  compare?: (a: any, b: any) => number
}

interface DataTableProps {
  columns: Column[]
  rows: any[]
  isLoading?: boolean
  triggerRef?: React.RefObject<HTMLDivElement | null>
  onRowClick?: (row: any, idx: number) => void
}

type SortDir = 'asc' | 'desc' | null

const DataTable = memo(
  ({ columns = [], rows = [], isLoading, triggerRef, onRowClick }: DataTableProps) => {
    const scrollRef = useRef<HTMLDivElement>(null)
    const [scrolled, setScrolled] = useState(false)

    useEffect(() => {
      const el = scrollRef.current
      if (!el) return
      const onScroll = () => setScrolled(el.scrollTop > 0)
      el.addEventListener('scroll', onScroll, { passive: true })
      onScroll()
      return () => el.removeEventListener('scroll', onScroll)
    }, [])

    // Sort state
    const [sortKey, setSortKey] = useState<string | null>(null)
    const [sortDir, setSortDir] = useState<SortDir>(null)

    const cycleDir = (prev: SortDir): SortDir =>
      prev === null ? 'asc' : prev === 'asc' ? 'desc' : null

    const handleSortClick = (col: Column) => {
      if (!col.sortable) return
      setSortKey((k) => {
        if (k !== col.key) {
          setSortDir('asc')
          return col.key
        }
        setSortDir((d) => cycleDir(d))
        return col.key
      })
    }

    // Default comparison
    const defaultCompare = (va: unknown, vb: unknown) => {
      if (typeof va === 'number' && typeof vb === 'number') return va - vb
      const da = Date.parse(String(va))
      const db = Date.parse(String(vb))
      if (!Number.isNaN(da) && !Number.isNaN(db)) return da - db
      return String(va ?? '').localeCompare(String(vb ?? ''), undefined, { sensitivity: 'base' })
    }

    const sortedRows = useMemo(() => {
      if (!sortKey || !sortDir) return rows
      const col = columns.find((c) => c.key === sortKey)
      if (!col) return rows
      const getVal = col.getValue ?? ((r: any) => (r as any)[col.key])
      const cmp = col.compare ?? ((a: any, b: any) => defaultCompare(getVal(a), getVal(b)))
      return [...rows].sort((a, b) => (sortDir === 'asc' ? cmp(a, b) : -cmp(a, b)))
    }, [rows, columns, sortKey, sortDir])

    return (
      <div className="overflow-hidden rounded-md border">
        <div ref={scrollRef} className="max-h-[83vh] overflow-auto">
          <Table className="w-full table-fixed">
            <TableHeader className={cn(scrolled && 'shadow-sm')}>
              <TableRow>
                {columns.map((c) => {
                  const active = sortKey === c.key ? sortDir : null
                  return (
                    <TableHead
                      key={c.key}
                      className={cn(
                        'sticky top-0 z-30 bg-white whitespace-nowrap',
                        c.sortable && 'cursor-pointer select-none'
                      )}
                      style={{ width: c.width ? `${c.width}px` : undefined }}
                      onClick={() => handleSortClick(c)}
                    >
                      <div className="flex items-center gap-1 px-2 py-3">
                        {c.label}
                        {c.sortable && (
                          <span className="text-muted-foreground text-xs">
                            {active === 'asc' && '▲'}
                            {active === 'desc' && '▼'}
                            {!active && '↕'}
                          </span>
                        )}
                      </div>
                    </TableHead>
                  )
                })}
              </TableRow>
            </TableHeader>

            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={columns.length} className="py-4 text-center">
                    <Loader className="mx-auto animate-spin" />
                  </TableCell>
                </TableRow>
              ) : sortedRows.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="text-muted-foreground py-6 text-center text-sm"
                  >
                    No data
                  </TableCell>
                </TableRow>
              ) : (
                sortedRows.map((r, idx) => (
                  <TableRow
                    key={r.id}
                    onClick={() => onRowClick?.(r, idx)}
                    className={cn('hover:bg-muted/50', onRowClick && 'cursor-pointer')}
                  >
                    {columns.map((c) => (
                      <TableCell
                        key={c.key}
                        className={c.key === 'bio' ? 'whitespace-normal' : 'truncate'}
                      >
                        {c.render ? c.render(r, idx) : String((r as any)?.[c.key] ?? '')}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              )}

              {triggerRef && (
                <TableRow>
                  <TableCell colSpan={columns.length}>
                    <div ref={triggerRef}></div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    )
  }
)

export default DataTable
