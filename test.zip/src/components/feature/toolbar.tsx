import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { StatusEnum, type InforModelMerge } from '@/model'
import { useDownloadInfos } from '@/shared/hooks/useHandleDownloadInfos'
import { cn, STATUS_LABEL } from '@/shared/utils'
import { Funnel, Plus, Search, Download, X } from 'lucide-react'
import { useEffect, useState } from 'react'

export type StatusFilterValue = 'all' | StatusEnum

export interface ToolbarProps {
  infos: InforModelMerge[]
  length: number
  className?: string
  onSearch?: (value: string) => void
  defaultSearch?: string
  onAddRow?: () => void
  status?: StatusFilterValue
  onStatusChange?: (value: StatusFilterValue) => void
}

const STATUS_OPTIONS: Array<{ value: StatusFilterValue; label: string }> = [
  { value: 'all', label: 'All' },
  { value: StatusEnum.active, label: STATUS_LABEL[StatusEnum.active] },
  { value: StatusEnum.needsReview, label: STATUS_LABEL[StatusEnum.needsReview] },
  { value: StatusEnum.inactive, label: STATUS_LABEL[StatusEnum.inactive] }
]

export function Toolbar({
  infos,
  length,
  className,
  onSearch,
  defaultSearch = '',
  onAddRow,
  status = 'all',
  onStatusChange
}: ToolbarProps) {
  const [search, setSearch] = useState(defaultSearch)
  useEffect(() => setSearch(defaultSearch), [defaultSearch])

  const { isLoading, progress, download, cancel } = useDownloadInfos(infos, {
    prebuild: true,
    chunkSize: 1000,
    filename: 'infor-list.csv',
    onProgress: (p) => {
      console.log('progress:', Math.round(p * 100), '%')
    }
  })

  const pct = Math.round(progress * 100)

  return (
    <div className={cn('flex flex-wrap items-center gap-2 border-b bg-white p-3', className)}>
      <p className="bg-gradient-to-r from-[#FF2E83] via-[#D54CFF] to-[#7B61FF] bg-clip-text text-2xl font-semibold text-transparent">
        Devtify
      </p>

      <div className="relative w-full max-w-sm">
        <Search className="text-muted-foreground pointer-events-none absolute top-1/2 left-2 size-4 -translate-y-1/2" />
        <Input
          value={search}
          onChange={(e) => {
            const v = e.target.value
            setSearch(v)
            onSearch?.(v)
          }}
          placeholder="Search by id, name, language..."
          className="pl-8"
        />
      </div>

      <div className="ml-auto flex items-center gap-2">
        <p className="text-sm text-gray-500">Showing {length.toLocaleString()} rows</p>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Funnel className="size-4" />
              <span className="hidden sm:inline">
                Status: {STATUS_OPTIONS.find((o) => o.value === status)?.label}
              </span>
              <span className="sm:hidden">
                {STATUS_OPTIONS.find((o) => o.value === status)?.label}
              </span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel>Filter by status</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuRadioGroup
              value={String(status)}
              onValueChange={(val) => {
                const option = STATUS_OPTIONS.find((o) => String(o.value) === val)
                if (option) onStatusChange?.(option.value)
              }}
            >
              {STATUS_OPTIONS.map((opt) => (
                <DropdownMenuRadioItem key={String(opt.value)} value={String(opt.value)}>
                  {opt.label}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuContent>
        </DropdownMenu>

        {onAddRow && (
          <Button onClick={onAddRow} className="gap-2">
            <Plus className="size-4" />
            Add
          </Button>
        )}

        {!isLoading ? (
          <Button
            variant="default"
            className="gap-2"
            onClick={download}
            disabled={!infos?.length}
            title={infos?.length ? 'Export CSV' : 'No data'}
          >
            <Download className="size-4" />
            Export CSV
          </Button>
        ) : (
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2" disabled>
              <Download className="size-4 animate-pulse" />
              Preparing {pct}%
            </Button>
            <Button variant="ghost" size="icon" onClick={cancel} title="Cancel export">
              <X className="size-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

export default Toolbar
